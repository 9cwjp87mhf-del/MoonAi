const BACKEND_URL = 'http://localhost:3000'; // Bei Deployment ändern (z.B. https://moonai-backend.onrender.com)
let token = localStorage.getItem('moonai_token');
let selectedFile = null;

// Init
if (token) {
    document.getElementById('auth-screen').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
}

// UI Helpers
function autoGrow(element) {
    element.style.height = "5px";
    element.style.height = (element.scrollHeight) + "px";
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('hidden');
    sidebar.classList.toggle('absolute');
    sidebar.classList.toggle('z-40');
    sidebar.classList.toggle('h-full');
}

// File Upload Handler
document.getElementById('file-upload').addEventListener('change', function(e) {
    selectedFile = e.target.files[0];
    const preview = document.getElementById('file-preview');
    if (selectedFile) {
        preview.textContent = `Angehängt: ${selectedFile.name}`;
        preview.classList.remove('hidden');
    }
});

// Auth
async function handleAuth(endpoint) {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorEl = document.getElementById('auth-error');
    
    try {
        const res = await fetch(`${BACKEND_URL}/auth/${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        
        if (data.token) {
            token = data.token;
            localStorage.setItem('moonai_token', token);
            document.getElementById('auth-screen').classList.add('hidden');
            document.getElementById('app').classList.remove('hidden');
        } else {
            errorEl.textContent = data.error || 'Fehler aufgetreten';
            errorEl.classList.remove('hidden');
        }
    } catch (err) {
        errorEl.textContent = 'Netzwerkfehler';
        errorEl.classList.remove('hidden');
    }
}

function login() { handleAuth('login'); }
function register() { handleAuth('register'); }
function logout() {
    token = null;
    localStorage.removeItem('moonai_token');
    document.getElementById('auth-screen').classList.remove('hidden');
    document.getElementById('app').classList.add('hidden');
}

// Chat Logic
async function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    if (!message && !selectedFile) return;

    document.getElementById('empty-state').classList.add('hidden');
    appendMessage('user', message, selectedFile);
    input.value = '';
    input.style.height = 'auto';

    // FormData für Multimodalität
    const formData = new FormData();
    formData.append('message', message);
    if (selectedFile) {
        formData.append('file', selectedFile);
        selectedFile = null;
        document.getElementById('file-preview').classList.add('hidden');
    }

    try {
        const res = await fetch(`${BACKEND_URL}/api/chat`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` },
            body: formData
        });
        const data = await res.json();
        appendMessage('ai', data.reply, null, data.imageUrl);
    } catch (err) {
        appendMessage('ai', 'Verbindungsfehler zum Server.');
    }
}

function appendMessage(sender, text, file = null, imageUrl = null) {
    const container = document.getElementById('messages-container');
    const div = document.createElement('div');
    div.className = `flex gap-4 ${sender === 'user' ? 'justify-end' : 'justify-start'}`;
    
    let content = `<div class="p-3 rounded-2xl max-w-[80%] ${sender === 'user' ? 'bg-gray-700' : 'bg-transparent text-gray-200'}">`;
    if (file) content += `<div class="text-xs text-blue-400 mb-1"><i class="fa-solid fa-paperclip"></i> ${file.name}</div>`;
    if (text) content += `<div>${text}</div>`;
    if (imageUrl) content += `<img src="${imageUrl}" class="mt-2 rounded-lg max-w-full h-auto">`;
    content += `</div>`;
    
    div.innerHTML = content;
    container.appendChild(div);
    document.getElementById('chat-window').scrollTop = document.getElementById('chat-window').scrollHeight;
}