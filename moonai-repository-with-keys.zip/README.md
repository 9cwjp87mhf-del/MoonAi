# MoonAi - Multimodale Chat-Anwendung

Eine moderne, an ChatGPT angelehnte KI-Webanwendung mit vollwertigem Clean Dark Mode, PWA-Support für iOS (iPhone), intelligentem API-Routing (OpenAI, Gemini, Mistral) und sicherem Benutzerkonten-System.

## Projektstruktur

- `/frontend`: Statische Webdateien bereitstellbar über **GitHub Pages**.
- `/backend`: Node.js Express Server bereitstellbar über **Render**, **Fly.io** oder **Heroku**.

## Einrichtung & Start

### Backend:
1. Navigiere in das `backend`-Verzeichnis.
2. Erstelle eine `.env`-Datei basierend auf `.env.example` und trage deine API-Schlüssel ein.
3. Führe `npm install` aus.
4. Starte den Server mit `npm start`.

### Frontend:
1. Passe in der `frontend/app.js` die `BACKEND_URL` an dein deploytes Backend an.
2. Lade den Inhalt des `frontend`-Ordners auf GitHub Pages hoch.
