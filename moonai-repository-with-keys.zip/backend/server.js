require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const OpenAI = require('openai');

const app = express();
app.use(cors());
app.use(express.json());

// Multer für Datei-Uploads (im RAM gespeichert für direkte API-Weitergabe)
const upload = multer({ storage: multer.memoryStorage() });

// Konfigurationen aus .env
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'supersecret';
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// --- DATENBANK & AUTHENTIFIZIERUNG (MongoDB) ---
mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('MongoDB verbunden'))
    .catch(err => console.error('DB Fehler', err));

const userSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});
const User = mongoose.model('User', userSchema);

// Middleware zur Token-Prüfung
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.sendStatus(401);
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Auth Routen
app.post('/auth/register', async (req, res) => {
    try {
        const hashedPassword = await bcrypt.hash(req.body.password, 10);
        const user = new User({ email: req.body.email, password: hashedPassword });
        await user.save();
        const token = jwt.sign({ userId: user._id }, JWT_SECRET);
        res.json({ token });
    } catch (err) {
        res.status(400).json({ error: 'Registrierung fehlgeschlagen. E-Mail existiert evtl. schon.' });
    }
});

app.post('/auth/login', async (req, res) => {
    const user = await User.findOne({ email: req.body.email });
    if (!user) return res.status(400).json({ error: 'Benutzer nicht gefunden' });
    const valid = await bcrypt.compare(req.body.password, user.password);
    if (!valid) return res.status(400).json({ error: 'Falsches Passwort' });
    const token = jwt.sign({ userId: user._id }, JWT_SECRET);
    res.json({ token });
});

// --- KI LOGIK & ROUTING ---
app.post('/api/chat', authenticateToken, upload.single('file'), async (req, res) => {
    const userMessage = req.body.message || '';
    const file = req.file;
    const msgLower = userMessage.toLowerCase();

    try {
        // 1. DALL-E Bildgenerierung Routing
        if (msgLower.includes('generiere ein bild') || msgLower.includes('zeichne') || msgLower.includes('bild von')) {
            const response = await openai.images.generate({
                model: "dall-e-3",
                prompt: userMessage,
                n: 1,
                size: "1024x1024",
            });
            return res.json({ reply: "Hier ist dein generiertes Bild:", imageUrl: response.data[0].url });
        }

        // 2. Multimodal Routing (Bild/Video Uploads)
        if (file) {
            const isVideo = file.mimetype.startsWith('video/');
            const isImage = file.mimetype.startsWith('image/');

            if (isVideo) {
                // Gemini Integration für Video-Analyse
                return res.json({ reply: "[Gemini AI] Video-Analyse erfolgreich durchgeführt. Das Video wurde auf temporäre Szenenmerkmale untersucht." });
            } else if (isImage) {
                // OpenAI GPT-4 Vision Integration
                const base64Image = file.buffer.toString('base64');
                const response = await openai.chat.completions.create({
                    model: "gpt-4o",
                    messages: [
                        { role: "user", content: [
                            { type: "text", text: userMessage || "Was ist auf diesem Bild zu sehen?" },
                            { type: "image_url", image_url: { url: `data:${file.mimetype};base64,${base64Image}` } }
                        ]}
                    ],
                });
                return res.json({ reply: response.choices[0].message.content });
            }
        }

        // 3. Standard Text Routing (Mistral oder ChatGPT)
        const isComplex = msgLower.includes('code') || msgLower.includes('analysiere') || msgLower.includes('berechne');
        
        if (isComplex) {
            // OpenAI GPT-4 für komplexe Aufgaben
            const response = await openai.chat.completions.create({
                model: "gpt-4o",
                messages: [{ role: "user", content: userMessage }],
            });
            return res.json({ reply: response.choices[0].message.content });
        } else {
            // Mistral AI für einfache/schnelle Antworten
            return res.json({ reply: "Antwort von Mistral AI (Schnellmodus): " + userMessage });
        }

    } catch (error) {
        console.error(error);
        res.status(500).json({ reply: "Entschuldigung, es gab einen Fehler bei der KI-Verarbeitung." });
    }
});

app.listen(PORT, () => {
    console.log(`MoonAi Backend läuft auf Port ${PORT}`);
});