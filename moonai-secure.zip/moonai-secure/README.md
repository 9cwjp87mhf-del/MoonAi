# 🌙 MoonAi – Multimodale KI-Webanwendung

Eine moderne, an ChatGPT angelehnte KI-App mit Dark Mode, PWA-Support (iOS) und intelligentem API-Routing (OpenAI, Gemini, Mistral).

---

## ⚠️ WICHTIG: API-Schlüssel-Sicherheit

> **Die API-Schlüssel aus dem ursprünglichen Repository waren öffentlich sichtbar. Du solltest sie SOFORT rotieren (ersetzen), auch wenn du das Repository privat hast.**

### Schlüssel sofort rotieren:
| Anbieter | Link |
|---|---|
| OpenAI | https://platform.openai.com/api-keys |
| Google Gemini | https://aistudio.google.com/app/apikey |
| Mistral | https://console.mistral.ai/api-keys |

### Grundregeln:
- ❌ Niemals API-Schlüssel in Code-Dateien schreiben
- ❌ Niemals `.env` in Git einchecken (ist in `.gitignore` gesperrt)
- ✅ Immer `.env.example` mit Platzhaltern bereitstellen
- ✅ Hosting-Plattformen nutzen ihre eigene Secret-Verwaltung (siehe unten)

---

## Projektstruktur

```
moonai-secure/
├── .gitignore              ← .env ist hier ausgeschlossen
├── README.md
├── frontend/
│   ├── index.html
│   ├── app.js
│   ├── styles.css
│   └── manifest.json
└── backend/
    ├── server.js
    ├── package.json
    └── .env.example        ← Vorlage ohne echte Schlüssel
```

---

## Einrichtung (lokal)

### Backend starten

```bash
cd backend
cp .env.example .env          # Datei anlegen
# .env öffnen und echte Werte eintragen
npm install
npm start
```

### Frontend öffnen

Die Datei `frontend/index.html` direkt im Browser öffnen  
oder über einen lokalen Server bereitstellen:

```bash
cd frontend
npx serve .
```

---

## Deployment

### Backend (Render, Fly.io, Railway …)

API-Schlüssel **nicht** in Dateien eintragen, sondern im Dashboard des Anbieters als **Environment Variables** / **Secrets** setzen:

```
JWT_SECRET      = <langer Zufallsstring>
MONGODB_URI     = mongodb+srv://...
OPENAI_API_KEY  = sk-...
GEMINI_API_KEY  = ...
MISTRAL_API_KEY = ...
ALLOWED_ORIGIN  = https://dein-frontend.github.io
```

### Frontend (GitHub Pages)

1. `BACKEND_URL` in `frontend/app.js` auf die Backend-URL setzen.
2. Den Inhalt des `frontend/`-Ordners in ein GitHub-Repository laden.
3. In den Repository-Einstellungen GitHub Pages aktivieren.

---

## Sicherheits-Verbesserungen gegenüber Original

| Bereich | Original | Jetzt |
|---|---|---|
| API-Schlüssel | In `.env` hardcodiert + im Repo | Nur via Umgebungsvariablen |
| JWT | Kein Ablauf, schwaches Secret | 7-Tage-Ablauf, Stärkeprüfung beim Start |
| Passwort-Hashing | Kostenfaktor 10 | Kostenfaktor 12 |
| Fehlermeldungen | Unterschied Login/Passwort-Fehler | Einheitliche Meldung (Anti-Enumeration) |
| Content Security Policy | Keine | Im HTML-Header gesetzt |
| XSS-Schutz | innerHTML mit User-Input | textContent / DOM-API |
| CORS | Wildcard | Konfigurierbar via `ALLOWED_ORIGIN` |
| Datei-Uploads | Unbegrenzte Größe | Max. 10 MB |
| Fehler-Details | Stack Trace nach außen | Nur internes Logging |
| Startup-Check | Keiner | Bricht ab bei fehlenden Secrets |
