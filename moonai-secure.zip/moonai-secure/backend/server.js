require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const OpenAI = require('openai');

// ─── Sicherheits-Check beim Start ───────────────────────────────────────────
const REQUIRED_ENV = ['JWT_SECRET', 'MONGODB_URI', 'OPENAI_API_KEY'];
const missing = REQUIRED_ENV.filter(k => !process.env[k]);
if (missing.length > 0) {
    console.error('❌ Fehlende Umgebungsvariablen:', missing.join(', '));
    console.error('   Bitte .env.example nach .env kopieren und ausfüllen.');
    process.exit(1);
}

// JWT_SECRET darf nicht der Standardwert aus dem Beispiel sein
if (process.env.JWT_SECRET === 'ERSETZE_MIT_EIGENEM_ZUFALLSSTRING' || process.env.JWT_SECRET.length < 32) {
    console.error('❌ JWT_SECRET ist zu schwach oder noch der Platzhalterwert. Bitte ändern!');
    process.exit(1);
}

const app = express();

// ─── CORS ───────────────────────────────────────────────────────────────────
// Im Produktivbetrieb die erlaubten Origins explizit einschränken:
// z.B.: origin: 'https://dein-frontend.github.io'
app.use(cors({
    origin: process.env.ALLOWED_ORIGIN || '*',
    methods: ['GET', 'POST'],
}));

app.use(express.json());

// ─── Datei-Uploads (RAM, max 10 MB) ─────────────────────────────────────────
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB
});

// ─── Konfiguration ───────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;

// API-Schlüssel werden ausschließlich aus process.env gelesen – nie hartcodiert
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// ─── Datenbank ───────────────────────────────────────────────────────────────
mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('✅ MongoDB verbunden'))
    .catch(err => {
        console.error('❌ DB-Verbindungsfehler:', err.message);
        process.exit(1);
    });

const userSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true },
    createdAt: { type: Date, default: Date.now },
});
const User = mongoose.model('User', userSchema);

// ─── JWT-Middleware ───────────────────────────────────────────────────────────
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Kein Token übermittelt.' });

    jwt.verify(token, JWT_SECRET, { algorithms: ['HS256'] }, (err, user) => {
        if (err) return res.status(403).json({ error: 'Token ungültig oder abgelaufen.' });
        req.user = user;
        next();
    });
};

// ─── Auth-Routen ─────────────────────────────────────────────────────────────
app.post('/auth/register', async (req, res) => {
    const { email, password } = req.body || {};
    if (!email || !password || password.length < 8) {
        return res.status(400).json({ error: 'E-Mail und Passwort (min. 8 Zeichen) erforderlich.' });
    }
    try {
        const hashedPassword = await bcrypt.hash(password, 12); // Kostenfaktor 12
        const user = new User({ email, password: hashedPassword });
        await user.save();
        const token = jwt.sign({ userId: user._id }, JWT_SECRET, {
            algorithm: 'HS256',
            expiresIn: '7d', // Token läuft nach 7 Tagen ab
        });
        res.json({ token });
    } catch (err) {
        // Kein detailliertes Fehlerobjekt nach außen geben
        res.status(400).json({ error: 'Registrierung fehlgeschlagen. E-Mail bereits vergeben?' });
    }
});

app.post('/auth/login', async (req, res) => {
    const { email, password } = req.body || {};
    if (!email || !password) {
        return res.status(400).json({ error: 'E-Mail und Passwort erforderlich.' });
    }

    // Gleiche Fehlermeldung für "nicht gefunden" und "falsches Passwort"
    // → verhindert User-Enumeration-Angriffe
    const genericError = { error: 'E-Mail oder Passwort falsch.' };

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(401).json(genericError);

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json(genericError);

    const token = jwt.sign({ userId: user._id }, JWT_SECRET, {
        algorithm: 'HS256',
        expiresIn: '7d',
    });
    res.json({ token });
});

// ─── KI-Routing ──────────────────────────────────────────────────────────────
app.post('/api/chat', authenticateToken, upload.single('file'), async (req, res) => {
    const userMessage = (req.body.message || '').trim();
    const file = req.file;
    const msgLower = userMessage.toLowerCase();

    if (!userMessage && !file) {
        return res.status(400).json({ reply: 'Bitte gib eine Nachricht oder Datei ein.' });
    }

    try {
        // 1. DALL-E Bildgenerierung
        const imageKeywords = ['generiere ein bild', 'zeichne', 'bild von', 'erstelle ein bild'];
        if (imageKeywords.some(kw => msgLower.includes(kw))) {
            const response = await openai.images.generate({
                model: 'dall-e-3',
                prompt: userMessage,
                n: 1,
                size: '1024x1024',
            });
            return res.json({ reply: 'Hier ist dein generiertes Bild:', imageUrl: response.data[0].url });
        }

        // 2. Multimodale Eingabe (Bild-Upload)
        if (file) {
            const isImage = file.mimetype.startsWith('image/');
            const isVideo = file.mimetype.startsWith('video/');

            if (isImage) {
                const base64Image = file.buffer.toString('base64');
                const response = await openai.chat.completions.create({
                    model: 'gpt-4o',
                    messages: [{
                        role: 'user',
                        content: [
                            { type: 'text', text: userMessage || 'Was ist auf diesem Bild zu sehen?' },
                            { type: 'image_url', image_url: { url: `data:${file.mimetype};base64,${base64Image}` } },
                        ],
                    }],
                });
                return res.json({ reply: response.choices[0].message.content });
            }

            if (isVideo) {
                // Platzhalter für Gemini Video-Integration
                return res.json({ reply: '[Gemini AI] Video-Analyse: Funktion wird demnächst aktiviert.' });
            }
        }

        // 3. Standard Text-Routing
        const complexKeywords = ['code', 'analysiere', 'berechne', 'erkläre', 'schreibe'];
        const isComplex = complexKeywords.some(kw => msgLower.includes(kw));

        if (isComplex) {
            const response = await openai.chat.completions.create({
                model: 'gpt-4o',
                messages: [{ role: 'user', content: userMessage }],
                max_tokens: 2048,
            });
            return res.json({ reply: response.choices[0].message.content });
        } else {
            // Mistral-Integration (Platzhalter bis SDK vollständig eingebunden)
            const response = await openai.chat.completions.create({
                model: 'gpt-4o-mini',
                messages: [{ role: 'user', content: userMessage }],
                max_tokens: 512,
            });
            return res.json({ reply: response.choices[0].message.content });
        }

    } catch (error) {
        // Nur internen Fehlercode loggen, kein Stack-Trace nach außen
        console.error('KI-Fehler:', error.status, error.code);
        res.status(500).json({ reply: 'Entschuldigung, es gab einen Fehler bei der KI-Verarbeitung.' });
    }
});

app.listen(PORT, () => {
    console.log(`🌙 MoonAi Backend läuft auf Port ${PORT}`);
});
